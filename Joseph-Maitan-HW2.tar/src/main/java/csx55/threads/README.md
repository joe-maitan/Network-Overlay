Example of how to run threads code: 

java -cp build/libs/csx55.jar csx55.threads.MatrixThreads 8 3000 31459