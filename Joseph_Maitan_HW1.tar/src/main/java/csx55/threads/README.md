Example of how to run threads code: java csx55.threads.MatrixThreads thread-pool-size matrix-dimension seed

java csx55.threads.MatrixThreads 8 3000 31459